let inventario = [  
    { id: 1, nombre: 'Laptop', marca: 'Dell', cantidad: 10 },  
    { id: 2, nombre: 'Telefono', marca: 'Apple', cantidad: 5 },  
    { id: 3, nombre: 'Tablet', marca: 'Samsung', cantidad: 7 },  
];  

module.exports = inventario;