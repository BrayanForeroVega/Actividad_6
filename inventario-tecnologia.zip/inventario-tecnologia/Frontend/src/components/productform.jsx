import React, { useState } from 'react';  
import axios from 'axios';  

const ProductForm = ({ refreshInventory }) => {  
    const [nombre, setNombre] = useState('');  
    const [marca, setMarca] = useState('');  
    const [cantidad, setCantidad] = useState('');  

    const handleSubmit = async (e) => {  
        e.preventDefault();  

        try {  
            await axios.post('http://localhost:3000', {  
                nombre,  
                marca,  
                cantidad: parseInt(cantidad),  
            });  
            refreshInventory();  
            setNombre('');  
            setMarca('');  
            setCantidad('');  
        } catch (error) {  
            console.error('Error al agregar el producto', error);  
        }  
    };  

    return (  
        <form onSubmit={handleSubmit}>  
            <input  
                type="text"  
                placeholder="Nombre"  
                value={nombre}  
                onChange={(e) => setNombre(e.target.value)}  
                required  
            />  
            <input  
                type="text"  
                placeholder="Marca"  
                value={marca}  
                onChange={(e) => setMarca(e.target.value)}  
                required  
            />  
            <input  
                type="number"  
                placeholder="Cantidad"  
                value={cantidad}  
                onChange={(e) => setCantidad(e.target.value)}  
                required  
            />  
            <button type="submit">Agregar Producto</button>  
        </form>  
    );  
};  

export default ProductForm;